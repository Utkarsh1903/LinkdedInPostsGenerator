/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './index.html',
    './src/**/*.{js,jsx,ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        surface: {
          DEFAULT: '#0d1117',
          card: '#161b22',
          hover: '#1f2937',
          border: '#30363d',
        },
      },
      boxShadow: {
        glow: '0 0 24px rgba(79,142,247,0.12)',
      },
    },
  },
  plugins: [],
}
