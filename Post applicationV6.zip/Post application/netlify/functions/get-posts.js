import { getStore } from '@netlify/blobs'

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  }
}

function respond(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', ...corsHeaders() },
    body: JSON.stringify(body),
  }
}

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: corsHeaders() }
  }

  if (event.httpMethod !== 'GET') {
    return respond(405, { error: 'Method not allowed' })
  }

  try {
    const store = getStore('daily-posts')
    const todayIST = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' })
    const raw = await store.get(todayIST)
    if (!raw) return respond(404, { error: 'No posts generated yet for today.' })
    return respond(200, JSON.parse(raw))
  } catch (err) {
    // Blobs not available in local dev — silently return 404 so UI falls back to localStorage
    if (err?.name === 'MissingBlobsEnvironmentError' || err?.message?.includes('MissingBlobsEnvironmentError')) {
      return respond(404, { error: 'No posts in store.' })
    }
    console.error('[get-posts] Error:', err)
    return respond(500, { error: 'Failed to fetch posts.' })
  }
}
