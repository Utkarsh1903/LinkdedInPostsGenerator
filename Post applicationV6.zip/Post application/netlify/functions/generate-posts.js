import { GoogleGenerativeAI } from '@google/generative-ai'
import OpenAI from 'openai'
import Groq from 'groq-sdk'
import { getStore } from '@netlify/blobs'

// ── Prompt ───────────────────────────────────────────────────────────────────

const SYSTEM_PROMPT = `You are a social media ghostwriter for a senior software engineer's personal brand on LinkedIn and X (Twitter).

LinkedIn rules:
- 150–250 words, short paragraphs, blank lines between them
- First line is a strong hook — NOT "Today I want to talk about..."
- End with a question or insight that invites comments
- 4–5 hashtags on the last line

X (Twitter) rules:
- MAXIMUM 280 characters total — count every character
- One punchy idea: hot take, relatable observation, or counterintuitive insight
- 0–2 hashtags only

Tone: direct, authentic, conversational — like a real engineer, not a marketer.
No buzzwords. No filler. No generic advice.`

function buildPrompt(topic) {
  return `Today is ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}.

Write one LinkedIn post and one X post for this software engineering topic:
"${topic.label}" — ${topic.description}

Return ONLY this JSON (no markdown, no extra keys):
{
  "linkedin": "<post with real newlines>",
  "twitter": "<tweet under 280 chars>"
}

Pick one specific, concrete angle. Not a generic overview.`
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function withTimeout(promise, ms, label) {
  return Promise.race([
    promise,
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`${label} timed out after ${ms / 1000}s`)), ms)
    ),
  ])
}

function isRateLimitError(err) {
  const msg = String(err?.message || '').toLowerCase()
  const status = err?.status
  return status === 429
    || msg.includes('429')
    || msg.includes('quota')
    || msg.includes('resource_exhausted')
    || msg.includes('too many requests')
    || msg.includes('rate limit')
}

function validatePost(parsed) {
  if (!parsed?.linkedin || !parsed?.twitter) {
    throw new Error('Incomplete response: missing linkedin or twitter field')
  }
}

// ── Gemini provider (tries multiple models, each has its own quota) ───────────

// Each model has its own independent free-tier quota of 1500 req/day
const GEMINI_MODELS = [
  'gemini-2.0-flash',
  'gemini-1.5-flash',
  'gemini-2.0-flash-lite',
  'gemini-1.5-flash-8b',
]

async function tryGeminiModel(topic, modelName) {
  if (!process.env.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY not set')

  const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY)
  const model = genAI.getGenerativeModel({
    model: modelName,
    systemInstruction: SYSTEM_PROMPT,
    generationConfig: {
      responseMimeType: 'application/json',
      temperature: 0.85,
      maxOutputTokens: 1200,
    },
  })

  const result = await withTimeout(
    model.generateContent(buildPrompt(topic)),
    15000,
    `Gemini/${modelName}`
  )

  const parsed = JSON.parse(result.response.text())
  validatePost(parsed)
  return { post: parsed, provider: `gemini/${modelName}` }
}

async function tryGemini(topic) {
  const errors = []
  for (const modelName of GEMINI_MODELS) {
    try {
      const result = await tryGeminiModel(topic, modelName)
      console.log(`[generate-posts] Gemini model ${modelName} succeeded`)
      return result
    } catch (err) {
      const reason = isRateLimitError(err) ? 'rate-limited' : err.message
      console.warn(`[generate-posts] Gemini/${modelName} failed: ${reason}`)
      errors.push(`${modelName}: ${reason}`)
      // Only skip to next model on rate limit — other errors (auth, parse) bubble up
      if (!isRateLimitError(err)) throw err
    }
  }
  // All Gemini models rate-limited
  const e = new Error(`All Gemini models rate-limited: ${errors.join(' | ')}`)
  e.allRateLimited = true
  throw e
}

// ── Groq provider ────────────────────────────────────────────────────────────
// Free tier: 14,400 req/day — runs Llama 3.3 70B

async function tryGroq(topic) {
  if (!process.env.GROQ_API_KEY) throw new Error('GROQ_API_KEY not set')

  const groq = new Groq({ apiKey: process.env.GROQ_API_KEY })

  const completion = await withTimeout(
    groq.chat.completions.create({
      model: 'llama-3.3-70b-versatile',
      temperature: 0.85,
      max_tokens: 1200,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user',   content: buildPrompt(topic) },
      ],
    }),
    15000,
    'Groq'
  )

  const raw = completion.choices[0]?.message?.content
  if (!raw) throw new Error('Groq: empty response')
  const parsed = JSON.parse(raw)
  validatePost(parsed)
  return { post: parsed, provider: 'groq/llama-3.3-70b' }
}

// ── OpenAI provider ───────────────────────────────────────────────────────────

async function tryOpenAI(topic) {
  if (!process.env.OPENAI_API_KEY) throw new Error('OPENAI_API_KEY not set')

  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

  const completion = await withTimeout(
    openai.chat.completions.create({
      model: 'gpt-4o-mini',
      temperature: 0.85,
      max_tokens: 1200,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user',   content: buildPrompt(topic) },
      ],
    }),
    15000,
    'OpenAI'
  )

  const raw = completion.choices[0]?.message?.content
  if (!raw) throw new Error('OpenAI: empty response')
  const parsed = JSON.parse(raw)
  validatePost(parsed)
  return { post: parsed, provider: 'openai/gpt-4o-mini' }
}

// ── Main handler ──────────────────────────────────────────────────────────────

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: corsHeaders() }
  }
  if (event.httpMethod !== 'POST') {
    return respond(405, { error: 'Method not allowed' })
  }

  if (!process.env.GEMINI_API_KEY && !process.env.OPENAI_API_KEY) {
    return respond(500, { error: 'No API keys configured. Add GEMINI_API_KEY or OPENAI_API_KEY to your .env file.' })
  }

  let topic
  try {
    const body = JSON.parse(event.body || '{}')
    topic = body.topic
    if (!topic?.id || !topic?.label) {
      return respond(400, { error: '"topic" with id and label is required.' })
    }
  } catch {
    return respond(400, { error: 'Invalid JSON body.' })
  }

  let result = null
  let geminiError = null

  // ── Try Gemini (4 models, each independent quota) ─────────────────────────
  try {
    result = await tryGemini(topic)
  } catch (err) {
    geminiError = err.message
    console.warn(`[generate-posts] All Gemini attempts failed: ${err.message}`)
  }

  // ── Try Groq fallback ────────────────────────────────────────────────────
  let groqError = null
  if (!result) {
    try {
      result = await tryGroq(topic)
    } catch (err) {
      groqError = err.message
      console.warn(`[generate-posts] Groq fallback failed: ${err.message}`)
    }
  }

  // ── Try OpenAI fallback ───────────────────────────────────────────────────
  if (!result) {
    try {
      result = await tryOpenAI(topic)
    } catch (err) {
      console.warn(`[generate-posts] OpenAI fallback failed: ${err.message}`)

      const allRateLimited = geminiError?.includes('rate-limited')
        && isRateLimitError({ message: groqError })
        && isRateLimitError(err)
      return respond(503, {
        error: allRateLimited
          ? 'Free quota exhausted on all providers for today. Resets at midnight. Try again tomorrow or add a paid API key.'
          : `Generation failed — Gemini: ${geminiError} | Groq: ${groqError} | OpenAI: ${err.message}`,
      })
    }
  }

  // ── Persist to Blobs (silently skip in local dev) ─────────────────────────
  try {
    const store = getStore('daily-posts')
    const todayIST = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' })
    const existing = await store.get(todayIST)
      .then(r => r ? JSON.parse(r) : { posts: {} })
      .catch(() => ({ posts: {} }))
    existing.posts[topic.id] = result.post
    existing.generatedAt = new Date().toISOString()
    await store.set(todayIST, JSON.stringify(existing))
  } catch {
    // Blobs not available in local dev — frontend localStorage handles caching
  }

  return respond(200, { topicId: topic.id, post: result.post, provider: result.provider })
}

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  }
}

function respond(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', ...corsHeaders() },
    body: JSON.stringify(body),
  }
}
