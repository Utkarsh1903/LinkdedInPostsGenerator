import React, { useState, useEffect, useCallback } from 'react'
import PostCard from './components/PostCard'

export const TOPICS = [
  { id: 'system-design',    label: 'System Design & Real-World Challenges', icon: '🏗️', gradient: 'from-blue-600 to-cyan-500',      description: 'Scalability, DB optimization, microservices, production incidents' },
  { id: 'company-problems', label: 'Real Company Problems & Solutions',      icon: '🏢', gradient: 'from-violet-600 to-indigo-500',  description: 'Case studies, postmortems, infrastructure scaling stories' },
  { id: 'daily-challenges', label: 'Daily Software Engineer Challenges',     icon: '⚡', gradient: 'from-yellow-500 to-orange-500',  description: 'Debugging, deployments, code reviews, legacy code' },
  { id: 'day-in-life',      label: 'Day-in-the-Life Content',               icon: '☀️', gradient: 'from-orange-500 to-rose-500',    description: 'Routines, stand-ups, work-life balance, remote work' },
  { id: 'junior-dev',       label: 'Fresher / Junior Developer Content',     icon: '🌱', gradient: 'from-emerald-500 to-teal-400',   description: 'Tips, common mistakes, first projects, imposter syndrome' },
  { id: 'interview-prep',   label: 'Interview Preparation',                  icon: '💼', gradient: 'from-purple-600 to-pink-500',    description: 'DSA strategies, system design rounds, success stories' },
  { id: 'ai-trends',        label: 'AI & Tech Trends',                       icon: '🤖', gradient: 'from-cyan-500 to-blue-500',      description: 'AI and jobs, layoffs, future-proof skills, AI tools for devs' },
  { id: 'humor',            label: 'Humorous / Fun Content',                 icon: '😄', gradient: 'from-pink-500 to-rose-400',      description: 'Relatable dev memes in text, funny tech situations' },
]

const CACHE_PREFIX = 'dpg_posts_'
const todayKeyIST = () => {
  const ist = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' })
  return `${CACHE_PREFIX}${ist}`
}

function saveToCache(posts) {
  localStorage.setItem(todayKeyIST(), JSON.stringify({ posts, generatedAt: new Date().toISOString() }))
}

export default function App() {
  const [posts, setPosts] = useState({})             // { [topicId]: { linkedin, twitter } }
  const [loading, setLoading] = useState({})         // { [topicId]: boolean }
  const [errors, setErrors] = useState({})           // { [topicId]: string }
  const [initialChecking, setInitialChecking] = useState(true)

  // On mount: check localStorage → then Blobs
  useEffect(() => {
    const init = async () => {
      try {
        const raw = localStorage.getItem(todayKeyIST())
        if (raw) {
          const cached = JSON.parse(raw)
          setPosts(cached.posts || {})
          setInitialChecking(false)
          return
        }
      } catch {
        localStorage.removeItem(todayKeyIST())
      }

      try {
        const res = await fetch('/.netlify/functions/get-posts')
        if (res.ok) {
          const data = await res.json()
          setPosts(data.posts || {})
          saveToCache(data.posts || {})
        }
      } catch {}

      setInitialChecking(false)
    }
    init()
  }, [])

  const generateTopic = useCallback(async (topic) => {
    setLoading(prev => ({ ...prev, [topic.id]: true }))
    setErrors(prev => ({ ...prev, [topic.id]: null }))

    try {
      const res = await fetch('/.netlify/functions/generate-posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: { id: topic.id, label: topic.label, description: topic.description } }),
      })
      const body = await res.json().catch(() => ({}))
      if (!res.ok) throw new Error(body.error || `Error ${res.status}`)

      setPosts(prev => {
        const updated = { ...prev, [topic.id]: body.post }
        saveToCache(updated)
        return updated
      })
    } catch (err) {
      setErrors(prev => ({ ...prev, [topic.id]: err.message || 'Failed to generate. Try again.' }))
    } finally {
      setLoading(prev => ({ ...prev, [topic.id]: false }))
    }
  }, [])

  const today = new Date().toLocaleDateString('en-US', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  })

  const generatedCount = Object.keys(posts).length

  return (
    <div className="min-h-screen bg-[#0d1117] text-[#e6edf3]">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-surface-border bg-[#0d1117]/90 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="text-xl">✍️</span>
            <span className="font-semibold text-white">Daily Post Generator</span>
          </div>
          {generatedCount > 0 && (
            <span className="text-xs text-gray-500">{generatedCount} / {TOPICS.length} generated today</span>
          )}
        </div>
      </header>

      {/* Hero */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-8 text-center">
        <p className="text-xs font-medium text-blue-400 uppercase tracking-widest mb-3">{today}</p>
        <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3 leading-tight">
          Your Daily{' '}
          <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
            Content Calendar
          </span>
        </h1>
        <p className="text-gray-500 text-sm max-w-md mx-auto">
          Click <strong className="text-gray-300">Generate</strong> on any topic card to create that post. Posts are saved for the day.
        </p>
      </section>

      {/* Cards grid */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
          {TOPICS.map(topic => (
            <PostCard
              key={topic.id}
              topic={topic}
              post={posts[topic.id] || null}
              isLoading={initialChecking || !!loading[topic.id]}
              error={errors[topic.id] || null}
              onGenerate={() => generateTopic(topic)}
            />
          ))}
        </div>
      </main>

      <footer className="border-t border-surface-border py-8 text-center space-y-1">
        <p className="text-gray-500 text-xs">Powered by Gemini &amp; OpenAI · Posts saved daily · Auto-generates at 9:30 AM IST</p>
        <p className="text-gray-600 text-xs">Developed by <span className="text-gray-400 font-medium">Utkarsh Srivastava</span></p>
      </footer>
    </div>
  )
}
