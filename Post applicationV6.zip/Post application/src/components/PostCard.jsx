import React, { useState, useCallback } from 'react'

const LinkedInIcon = () => (
  <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
  </svg>
)

const XIcon = () => (
  <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.746l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
  </svg>
)

function Shimmer({ className }) {
  return <div className={`bg-surface-hover rounded-md animate-pulse ${className}`} />
}

function CopyButton({ text, label }) {
  const [copied, setCopied] = useState(false)

  const handleCopy = useCallback(async () => {
    try { await navigator.clipboard.writeText(text) } catch {
      const el = document.createElement('textarea')
      el.value = text
      el.style.cssText = 'position:fixed;opacity:0'
      document.body.appendChild(el)
      el.select()
      document.execCommand('copy')
      document.body.removeChild(el)
    }
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }, [text])

  return (
    <button
      onClick={handleCopy}
      className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-semibold transition-all duration-150
        ${copied
          ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-400'
          : 'bg-surface-hover border border-surface-border text-gray-400 hover:text-white hover:border-blue-500/50 hover:bg-blue-500/10'
        }`}
    >
      {copied ? (
        <>
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
          </svg>
          Copied!
        </>
      ) : (
        <>
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
          </svg>
          Copy {label} post
        </>
      )}
    </button>
  )
}

export default function PostCard({ topic, post, isLoading, error, onGenerate }) {
  const [tab, setTab] = useState('linkedin')

  const cardHeader = (
    <>
      <div className={`h-1 w-full bg-gradient-to-r ${topic.gradient}`} />
      <div className="px-4 pt-4 pb-3 flex items-start gap-3">
        <span className="text-2xl leading-none mt-0.5">{topic.icon}</span>
        <div className="min-w-0">
          <h3 className="text-white font-semibold text-sm leading-snug">{topic.label}</h3>
          <p className="text-gray-600 text-xs mt-0.5 leading-snug">{topic.description}</p>
        </div>
      </div>
    </>
  )

  // ── Loading state ──────────────────────────────────────────
  if (isLoading) {
    return (
      <article className="bg-surface-card border border-surface-border rounded-2xl flex flex-col overflow-hidden">
        {cardHeader}
        <div className="flex border-y border-surface-border">
          <Shimmer className="flex-1 h-8 rounded-none" />
          <Shimmer className="flex-1 h-8 rounded-none border-l border-surface-border" />
        </div>
        <div className="flex-1 px-4 py-4 space-y-2.5">
          {[...Array(6)].map((_, i) => (
            <Shimmer key={i} className={`h-3 ${i % 3 === 2 ? 'w-3/5' : 'w-full'}`} />
          ))}
        </div>
        <div className="px-4 pb-4">
          <Shimmer className="h-10 w-full rounded-xl" />
        </div>
      </article>
    )
  }

  // ── Empty state ────────────────────────────────────────────
  if (!post) {
    return (
      <article className="bg-surface-card border border-surface-border rounded-2xl flex flex-col overflow-hidden hover:border-blue-500/30 transition-all duration-200">
        {cardHeader}
        <div className="flex-1 flex flex-col items-center justify-center px-4 py-8 gap-4">
          <p className="text-gray-600 text-xs text-center">No post generated yet for today</p>
          {error && (
            <p className="text-red-400 text-xs text-center">{error}</p>
          )}
          <button
            onClick={onGenerate}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 active:scale-95 text-white text-xs font-semibold transition-all duration-150"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            Generate Post
          </button>
        </div>
      </article>
    )
  }

  // ── Generated state ────────────────────────────────────────
  const isLinkedIn = tab === 'linkedin'
  const text = isLinkedIn ? post.linkedin : post.twitter

  return (
    <article className="bg-surface-card border border-surface-border rounded-2xl flex flex-col overflow-hidden hover:border-blue-500/30 transition-all duration-200 hover:shadow-glow">
      {cardHeader}

      {/* Platform tabs */}
      <div className="flex border-y border-surface-border">
        <button
          onClick={() => setTab('linkedin')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-medium transition-colors
            ${isLinkedIn ? 'bg-[#0077b5]/15 text-[#4fa3d1] border-b-2 border-[#0077b5]' : 'text-gray-500 hover:text-gray-300 hover:bg-surface-hover'}`}
        >
          <LinkedInIcon /> LinkedIn
        </button>
        <button
          onClick={() => setTab('twitter')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-medium transition-colors border-l border-surface-border
            ${!isLinkedIn ? 'bg-white/5 text-white border-b-2 border-white' : 'text-gray-500 hover:text-gray-300 hover:bg-surface-hover'}`}
        >
          <XIcon /> X (Twitter)
        </button>
      </div>

      {/* Post content */}
      <div className="flex-1 px-4 py-4 overflow-auto max-h-72">
        <p className="text-gray-300 text-sm leading-relaxed whitespace-pre-wrap break-words">{text}</p>
      </div>

      {/* Char count + actions */}
      <div className="px-4 pb-4 space-y-2">
        <div className="flex items-center justify-between">
          <button
            onClick={onGenerate}
            className="text-xs text-gray-600 hover:text-blue-400 transition-colors"
          >
            ↻ Regenerate
          </button>
          <span className={`text-xs tabular-nums ${!isLinkedIn && text.length > 280 ? 'text-red-400' : 'text-gray-600'}`}>
            {text.length}{!isLinkedIn && ' / 280'} chars
          </span>
        </div>
        <CopyButton text={text} label={isLinkedIn ? 'LinkedIn' : 'X'} />
      </div>
    </article>
  )
}
