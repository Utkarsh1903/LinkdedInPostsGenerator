import { GoogleGenerativeAI } from '@google/generative-ai'
import OpenAI from 'openai'
import { getStore } from '@netlify/blobs'

// ── Shared prompt ────────────────────────────────────────────────────────────

const SYSTEM_PROMPT = `You are a social media ghostwriter for a senior software engineer's personal brand on LinkedIn and X (Twitter).

LinkedIn rules:
- 150–250 words, short paragraphs, blank lines between them
- First line is a strong hook — NOT "Today I want to talk about..."
- End with a question or insight that invites comments
- 4–5 hashtags on the last line

X (Twitter) rules:
- MAXIMUM 280 characters total — count every character
- One punchy idea: hot take, relatable observation, or counterintuitive insight
- 0–2 hashtags only

Tone: direct, authentic, conversational — like a real engineer, not a marketer.
No buzzwords. No filler. No generic advice.`

function buildPrompt(topic) {
  return `Today is ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}.

Write one LinkedIn post and one X post for this software engineering topic:
"${topic.label}" — ${topic.description}

Return ONLY this JSON (no markdown, no extra keys):
{
  "linkedin": "<post with real newlines>",
  "twitter": "<tweet under 280 chars>"
}

Pick one specific, concrete angle. Not a generic overview.`
}

// ── Timeout helper ───────────────────────────────────────────────────────────

function withTimeout(promise, ms, label) {
  return Promise.race([
    promise,
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`${label} timed out after ${ms / 1000}s`)), ms)
    ),
  ])
}

function isRateLimitError(err) {
  return err?.status === 429
    || String(err?.message).includes('429')
    || String(err?.message).toLowerCase().includes('quota')
    || String(err?.message).toLowerCase().includes('resource_exhausted')
}

// ── Provider: Gemini ─────────────────────────────────────────────────────────

async function tryGemini(topic) {
  if (!process.env.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY not set')

  const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY)
  const model = genAI.getGenerativeModel({
    model: 'gemini-2.0-flash',
    systemInstruction: SYSTEM_PROMPT,
    generationConfig: {
      responseMimeType: 'application/json',
      temperature: 0.85,
      maxOutputTokens: 1200,
    },
  })

  const result = await withTimeout(
    model.generateContent(buildPrompt(topic)),
    15000,
    'Gemini'
  )

  const raw = result.response.text()
  const parsed = JSON.parse(raw)
  if (!parsed.linkedin || !parsed.twitter) throw new Error('Gemini: incomplete response fields')
  return { post: parsed, provider: 'gemini' }
}

// ── Provider: OpenAI ─────────────────────────────────────────────────────────

async function tryOpenAI(topic) {
  if (!process.env.OPENAI_API_KEY) throw new Error('OPENAI_API_KEY not set')

  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

  const completion = await withTimeout(
    openai.chat.completions.create({
      model: 'gpt-4o-mini',
      temperature: 0.85,
      max_tokens: 1200,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user',   content: buildPrompt(topic) },
      ],
    }),
    15000,
    'OpenAI'
  )

  const raw = completion.choices[0]?.message?.content
  if (!raw) throw new Error('OpenAI: empty response')
  const parsed = JSON.parse(raw)
  if (!parsed.linkedin || !parsed.twitter) throw new Error('OpenAI: incomplete response fields')
  return { post: parsed, provider: 'openai' }
}

// ── Main handler ─────────────────────────────────────────────────────────────

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: corsHeaders() }
  }
  if (event.httpMethod !== 'POST') {
    return respond(405, { error: 'Method not allowed' })
  }

  let topic
  try {
    const body = JSON.parse(event.body || '{}')
    topic = body.topic
    if (!topic?.id || !topic?.label) {
      return respond(400, { error: '"topic" with id and label is required.' })
    }
  } catch {
    return respond(400, { error: 'Invalid JSON body.' })
  }

  const errors = []
  let result = null

  // ── Attempt 1: Gemini ──────────────────────────────────────────────────────
  try {
    result = await tryGemini(topic)
    console.log(`[generate-posts] Gemini OK for topic: ${topic.id}`)
  } catch (err) {
    const reason = isRateLimitError(err) ? 'rate-limited' : err.message
    console.warn(`[generate-posts] Gemini failed (${reason}) — trying OpenAI`)
    errors.push(`Gemini: ${reason}`)
  }

  // ── Attempt 2: OpenAI (fallback) ───────────────────────────────────────────
  if (!result) {
    try {
      result = await tryOpenAI(topic)
      console.log(`[generate-posts] OpenAI fallback OK for topic: ${topic.id}`)
    } catch (err) {
      const reason = isRateLimitError(err) ? 'rate-limited' : err.message
      console.warn(`[generate-posts] OpenAI failed (${reason})`)
      errors.push(`OpenAI: ${reason}`)
    }
  }

  // ── Both failed ────────────────────────────────────────────────────────────
  if (!result) {
    console.error('[generate-posts] All providers failed:', errors)
    const allRateLimited = errors.every(e => e.includes('rate-limited'))
    return respond(503, {
      error: allRateLimited
        ? 'Both AI providers are temporarily rate-limited. Please try again in a minute.'
        : `Generation failed: ${errors.join(' | ')}`,
    })
  }

  // ── Save to Blobs (deployed only, silently skip locally) ───────────────────
  try {
    const store = getStore('daily-posts')
    const todayIST = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' })
    const existing = await store.get(todayIST)
      .then(r => r ? JSON.parse(r) : { posts: {} })
      .catch(() => ({ posts: {} }))
    existing.posts[topic.id] = result.post
    existing.generatedAt = new Date().toISOString()
    await store.set(todayIST, JSON.stringify(existing))
  } catch {
    // Not available in local dev — localStorage handles caching on the frontend
  }

  return respond(200, { topicId: topic.id, post: result.post, provider: result.provider })
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  }
}

function respond(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', ...corsHeaders() },
    body: JSON.stringify(body),
  }
}
