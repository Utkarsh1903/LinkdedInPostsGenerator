import React from 'react'

function Shimmer({ className }) {
  return <div className={`bg-surface-hover rounded-md animate-pulse ${className}`} />
}

export default function LoadingCard({ topic }) {
  return (
    <article className="bg-surface-card border border-surface-border rounded-2xl flex flex-col overflow-hidden">
      <div className={`h-1 w-full bg-gradient-to-r ${topic.gradient} opacity-40`} />
      <div className="px-4 pt-4 pb-3 flex items-start gap-3">
        <span className="text-2xl opacity-30">{topic.icon}</span>
        <div className="flex-1 space-y-1.5 pt-1">
          <Shimmer className="h-3.5 w-3/4" />
          <Shimmer className="h-2.5 w-1/2" />
        </div>
      </div>

      <div className="border-y border-surface-border flex">
        <Shimmer className="flex-1 h-8 rounded-none" />
        <Shimmer className="flex-1 h-8 rounded-none border-l border-surface-border" />
      </div>

      <div className="flex-1 px-4 py-4 space-y-2.5">
        {[...Array(7)].map((_, i) => (
          <Shimmer key={i} className={`h-3 ${i % 3 === 2 ? 'w-3/5' : 'w-full'}`} />
        ))}
      </div>

      <div className="px-4 pb-4 space-y-2.5">
        <div className="flex justify-end">
          <Shimmer className="h-2.5 w-16" />
        </div>
        <Shimmer className="h-10 w-full rounded-xl" />
      </div>
    </article>
  )
}
