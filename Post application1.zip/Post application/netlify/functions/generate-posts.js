import { GoogleGenerativeAI } from '@google/generative-ai'
import { getStore } from '@netlify/blobs'

const SYSTEM_PROMPT = `You are a social media content strategist and ghostwriter specialising in software engineering content. You write for a senior software engineer's personal brand on LinkedIn and X (Twitter).

Your writing style:
- Authentic and conversational — sounds like a real engineer, not a content marketer
- Specific and concrete — includes realistic scenarios, numbers, and technical detail
- Avoids overused phrases: "game-changer", "paradigm shift", "In today's fast-paced world", "It's important to note"
- Direct and opinionated — shares genuine takes, not generic advice

LinkedIn post rules:
- 150–280 words
- Strong hook in the first line (NOT "Today I want to talk about..." — make it a statement, observation, or question)
- Short paragraphs (2–4 lines max), with blank lines between them for readability
- Ends with a thought-provoking question OR a punchy insight that invites comments
- 4–5 relevant hashtags on the last line, separated by spaces

X (Twitter) post rules:
- HARD LIMIT: 280 characters total including hashtags and spaces — COUNT EVERY CHARACTER
- Single punchy idea: a hot take, a relatable observation, or a counterintuitive insight
- First sentence must hook in under 80 characters
- 0–2 hashtags only
- No filler, no corporate speak`

function buildPrompt(topics) {
  return `Today is ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}.

Generate one LinkedIn post and one X (Twitter) post for each of the following ${topics.length} software engineering topics.

Topics:
${topics.map(t => `- id: "${t.id}" | "${t.label}" — angle: ${t.description}`).join('\n')}

Return ONLY a valid JSON object with this exact shape:
{
  "posts": {
    "<topic-id>": {
      "linkedin": "<full post text using real newline characters for paragraph breaks>",
      "twitter": "<tweet, STRICTLY under 280 chars>"
    }
  }
}

All ${topics.length} topic IDs must be present: ${topics.map(t => `"${t.id}"`).join(', ')}.
Pick a specific angle for each topic — rotate between sub-angles so content is varied and fresh.`
}

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: corsHeaders() }
  }
  if (event.httpMethod !== 'POST') {
    return respond(405, { error: 'Method not allowed' })
  }
  if (!process.env.GEMINI_API_KEY) {
    console.error('[generate-posts] GEMINI_API_KEY is not set')
    return respond(500, { error: 'Server misconfiguration: API key missing.' })
  }

  let topics
  try {
    const body = JSON.parse(event.body || '{}')
    topics = body.topics
    if (!Array.isArray(topics) || topics.length === 0) {
      return respond(400, { error: '"topics" array is required.' })
    }
  } catch {
    return respond(400, { error: 'Invalid JSON body.' })
  }

  try {
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY)
    const model = genAI.getGenerativeModel({
      model: 'gemini-1.5-flash',
      systemInstruction: SYSTEM_PROMPT,
      generationConfig: {
        responseMimeType: 'application/json',
        temperature: 0.85,
        maxOutputTokens: 6000,
      },
    })

    const result = await model.generateContent(buildPrompt(topics))
    const raw = result.response.text()

    let parsed
    try {
      parsed = JSON.parse(raw)
    } catch {
      console.error('[generate-posts] Non-JSON from Gemini:', raw.slice(0, 400))
      return respond(502, { error: 'Failed to parse AI response. Please try again.' })
    }

    if (!parsed.posts || typeof parsed.posts !== 'object') {
      return respond(502, { error: 'Unexpected response shape. Please try again.' })
    }

    for (const { id } of topics) {
      if (!parsed.posts[id]) {
        parsed.posts[id] = {
          linkedin: 'Content for this topic could not be generated. Please regenerate.',
          twitter:  'Content for this topic could not be generated. Please regenerate.',
        }
      }
    }

    try {
      const store = getStore('daily-posts')
      const todayIST = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' })
      await store.set(todayIST, JSON.stringify({
        posts: parsed.posts,
        generatedAt: new Date().toISOString(),
        source: 'manual',
      }))
    } catch (blobErr) {
      console.warn('[generate-posts] Failed to save to Blobs:', blobErr.message)
    }

    return respond(200, { posts: parsed.posts })
  } catch (err) {
    if (err?.status === 429 || err?.message?.toLowerCase().includes('quota')) {
      return respond(429, { error: 'rate_limited' })
    }
    console.error('[generate-posts] Error:', err)
    return respond(500, { error: 'Failed to generate posts. Please try again.' })
  }
}

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  }
}

function respond(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', ...corsHeaders() },
    body: JSON.stringify(body),
  }
}
