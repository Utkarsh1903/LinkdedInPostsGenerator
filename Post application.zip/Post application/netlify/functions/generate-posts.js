import OpenAI from 'openai'
import { getStore } from '@netlify/blobs'

const SYSTEM_PROMPT = `You are a social media content strategist and ghostwriter specialising in software engineering content. You write for a senior software engineer's personal brand on LinkedIn and X (Twitter).

Your writing style:
- Authentic and conversational — sounds like a real engineer, not a content marketer
- Specific and concrete — includes realistic scenarios, numbers, and technical detail
- Avoids overused phrases: "game-changer", "paradigm shift", "In today's fast-paced world", "It's important to note"
- Direct and opinionated — shares genuine takes, not generic advice

LinkedIn post rules:
- 150–280 words
- Strong hook in the first line (NOT "Today I want to talk about..." — make it a statement, observation, or question)
- Short paragraphs (2–4 lines max), with blank lines between them for readability
- Ends with a thought-provoking question OR a punchy insight that invites comments
- 4–5 relevant hashtags on the last line, separated by spaces

X (Twitter) post rules:
- HARD LIMIT: 280 characters total including hashtags and spaces — COUNT EVERY CHARACTER
- Single punchy idea: a hot take, a relatable observation, or a counterintuitive insight
- First sentence must hook in under 80 characters
- 0–2 hashtags only (skip them if they'd waste characters)
- No filler, no corporate speak`

function buildPrompt(topics) {
  return `Today is ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}.

Generate one LinkedIn post and one X (Twitter) post for each of the following ${topics.length} software engineering topics.

Topics:
${topics.map(t => `- id: "${t.id}" | "${t.label}" — angle: ${t.description}`).join('\n')}

Return ONLY a valid JSON object with this exact shape (no markdown fences, no extra keys):
{
  "posts": {
    "<topic-id>": {
      "linkedin": "<full post text using real newline characters \\n for paragraph breaks>",
      "twitter": "<tweet, STRICTLY under 280 chars>"
    }
  }
}

All ${topics.length} topic IDs must be present: ${topics.map(t => `"${t.id}"`).join(', ')}.

Important: for each topic, pick a specific angle or subtopic (not a generic overview), so posts feel fresh and specific. Rotate between different subtopics so the content isn't repetitive across topics.`
}

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: corsHeaders() }
  }

  if (event.httpMethod !== 'POST') {
    return respond(405, { error: 'Method not allowed' })
  }

  if (!process.env.OPENAI_API_KEY) {
    console.error('[generate-posts] OPENAI_API_KEY is not set')
    return respond(500, { error: 'Server misconfiguration: API key missing.' })
  }

  let topics
  try {
    const body = JSON.parse(event.body || '{}')
    topics = body.topics
    if (!Array.isArray(topics) || topics.length === 0) {
      return respond(400, { error: '"topics" array is required in the request body.' })
    }
  } catch {
    return respond(400, { error: 'Invalid JSON body.' })
  }

  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      temperature: 0.85,
      max_tokens: 6000,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: buildPrompt(topics) },
      ],
    })

    const raw = completion.choices[0]?.message?.content
    if (!raw) return respond(502, { error: 'Empty response from OpenAI.' })

    let parsed
    try {
      parsed = JSON.parse(raw)
    } catch {
      console.error('[generate-posts] Non-JSON from OpenAI:', raw.slice(0, 400))
      return respond(502, { error: 'Failed to parse AI response. Please try again.' })
    }

    if (!parsed.posts || typeof parsed.posts !== 'object') {
      return respond(502, { error: 'Unexpected response shape from AI. Please try again.' })
    }

    // Graceful fallback for any missing topics
    for (const { id } of topics) {
      if (!parsed.posts[id]) {
        parsed.posts[id] = {
          linkedin: 'Content for this topic could not be generated. Please regenerate.',
          twitter: 'Content for this topic could not be generated. Please regenerate.',
        }
      }
    }

    // Save to Netlify Blobs so get-posts can serve it without re-generating
    try {
      const store = getStore('daily-posts')
      const todayIST = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' })
      await store.set(todayIST, JSON.stringify({
        posts: parsed.posts,
        generatedAt: new Date().toISOString(),
        source: 'manual',
      }))
    } catch (blobErr) {
      // Non-fatal — still return posts to the client
      console.warn('[generate-posts] Failed to save to Blobs:', blobErr.message)
    }

    return respond(200, { posts: parsed.posts })
  } catch (err) {
    if (err?.status === 429) return respond(429, { error: 'Rate limit hit. Wait a moment and try again.' })
    if (err?.status === 401) return respond(401, { error: 'Invalid OpenAI API key. Check your Netlify environment variables.' })
    if (err?.status === 503) return respond(503, { error: 'OpenAI is temporarily unavailable. Try again shortly.' })
    console.error('[generate-posts] Unexpected error:', err)
    return respond(500, { error: 'Failed to generate posts. Please try again.' })
  }
}

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  }
}

function respond(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', ...corsHeaders() },
    body: JSON.stringify(body),
  }
}
