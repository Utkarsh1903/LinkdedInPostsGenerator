import { schedule } from '@netlify/functions'
import { getStore } from '@netlify/blobs'
import OpenAI from 'openai'

// 9:30 AM IST = 04:00 AM UTC
const CRON = '0 4 * * *'

const TOPICS = [
  { id: 'system-design',    label: 'System Design & Real-World Challenges',  description: 'Scalability, DB optimization, microservices, production incidents' },
  { id: 'company-problems', label: 'Real Company Problems & Solutions',       description: 'Case studies, postmortems, infrastructure scaling stories' },
  { id: 'daily-challenges', label: 'Daily Software Engineer Challenges',      description: 'Debugging, deployments, code reviews, legacy code' },
  { id: 'day-in-life',      label: 'Day-in-the-Life Content',                description: 'Routines, stand-ups, work-life balance, remote work' },
  { id: 'junior-dev',       label: 'Fresher / Junior Developer Content',      description: 'Tips, common mistakes, first projects, imposter syndrome' },
  { id: 'interview-prep',   label: 'Interview Preparation',                  description: 'DSA strategies, system design rounds, success stories' },
  { id: 'ai-trends',        label: 'AI & Tech Trends',                       description: 'AI and jobs, layoffs, future-proof skills, AI tools for devs' },
  { id: 'humor',            label: 'Humorous / Fun Content',                 description: 'Relatable dev memes in text, funny tech situations' },
]

const SYSTEM_PROMPT = `You are a social media content strategist and ghostwriter specialising in software engineering content. You write for a senior software engineer's personal brand on LinkedIn and X (Twitter).

Your writing style:
- Authentic and conversational — sounds like a real engineer, not a content marketer
- Specific and concrete — includes realistic scenarios, numbers, and technical detail
- Avoids overused phrases: "game-changer", "paradigm shift", "In today's fast-paced world", "It's important to note"
- Direct and opinionated — shares genuine takes, not generic advice

LinkedIn post rules:
- 150–280 words
- Strong hook in the first line (NOT "Today I want to talk about..." — make it a statement, observation, or question)
- Short paragraphs (2–4 lines max), with blank lines between them for readability
- Ends with a thought-provoking question OR a punchy insight that invites comments
- 4–5 relevant hashtags on the last line, separated by spaces

X (Twitter) post rules:
- HARD LIMIT: 280 characters total including hashtags and spaces — COUNT EVERY CHARACTER
- Single punchy idea: a hot take, a relatable observation, or a counterintuitive insight
- First sentence must hook in under 80 characters
- 0–2 hashtags only (skip them if they'd waste characters)
- No filler, no corporate speak`

function buildPrompt(topics) {
  return `Today is ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}.

Generate one LinkedIn post and one X (Twitter) post for each of the following ${topics.length} software engineering topics.

Topics:
${topics.map(t => `- id: "${t.id}" | "${t.label}" — angle: ${t.description}`).join('\n')}

Return ONLY a valid JSON object with this exact shape (no markdown fences, no extra keys):
{
  "posts": {
    "<topic-id>": {
      "linkedin": "<full post text using real newline characters \\n for paragraph breaks>",
      "twitter": "<tweet, STRICTLY under 280 chars>"
    }
  }
}

All ${topics.length} topic IDs must be present: ${topics.map(t => `"${t.id}"`).join(', ')}.

Pick a specific angle or subtopic for each one — rotate between different sub-angles so the content is varied and fresh every day.`
}

async function generateAndStore() {
  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

  const completion = await openai.chat.completions.create({
    model: 'gpt-4o',
    temperature: 0.85,
    max_tokens: 6000,
    response_format: { type: 'json_object' },
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user',   content: buildPrompt(TOPICS) },
    ],
  })

  const raw = completion.choices[0]?.message?.content
  if (!raw) throw new Error('Empty response from OpenAI')

  const parsed = JSON.parse(raw)
  if (!parsed.posts || typeof parsed.posts !== 'object') {
    throw new Error('Unexpected response shape from OpenAI')
  }

  // Fill any missing topics
  for (const { id } of TOPICS) {
    if (!parsed.posts[id]) {
      parsed.posts[id] = {
        linkedin: 'Content for this topic could not be generated.',
        twitter:  'Content for this topic could not be generated.',
      }
    }
  }

  // Save to Netlify Blobs — key is today's date in IST
  const store = getStore('daily-posts')
  const todayIST = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' }) // YYYY-MM-DD
  const payload = { posts: parsed.posts, generatedAt: new Date().toISOString(), source: 'scheduled' }
  await store.set(todayIST, JSON.stringify(payload))

  console.log(`[scheduled-generate] Posts saved for ${todayIST}`)
  return todayIST
}

export const handler = schedule(CRON, async () => {
  if (!process.env.OPENAI_API_KEY) {
    console.error('[scheduled-generate] OPENAI_API_KEY is not set')
    return { statusCode: 500 }
  }

  try {
    const date = await generateAndStore()
    return { statusCode: 200, body: JSON.stringify({ ok: true, date }) }
  } catch (err) {
    console.error('[scheduled-generate] Error:', err)
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) }
  }
})
