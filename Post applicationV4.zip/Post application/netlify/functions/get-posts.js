import { getStore } from '@netlify/blobs'

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  }
}

function respond(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', ...corsHeaders() },
    body: JSON.stringify(body),
  }
}

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: corsHeaders() }
  }

  if (event.httpMethod !== 'GET') {
    return respond(405, { error: 'Method not allowed' })
  }

  try {
    const store = getStore('daily-posts')
    const todayIST = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' }) // YYYY-MM-DD

    const raw = await store.get(todayIST)
    if (!raw) {
      return respond(404, { error: 'No posts generated yet for today.' })
    }

    const data = JSON.parse(raw)
    return respond(200, data)
  } catch (err) {
    console.error('[get-posts] Error:', err)
    return respond(500, { error: 'Failed to fetch posts.' })
  }
}
