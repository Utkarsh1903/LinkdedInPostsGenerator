import { GoogleGenerativeAI } from '@google/generative-ai'
import { getStore } from '@netlify/blobs'

const SYSTEM_PROMPT = `You are a social media content strategist and ghostwriter specialising in software engineering content. You write for a senior software engineer's personal brand on LinkedIn and X (Twitter).

Your writing style:
- Authentic and conversational — sounds like a real engineer, not a content marketer
- Specific and concrete — includes realistic scenarios, numbers, and technical detail
- Avoids overused phrases: "game-changer", "paradigm shift", "In today's fast-paced world"
- Direct and opinionated — shares genuine takes, not generic advice

LinkedIn post rules:
- 150–280 words
- Strong hook in the first line (NOT "Today I want to talk about...")
- Short paragraphs with blank lines between them for readability
- Ends with a thought-provoking question or punchy insight
- 4–5 relevant hashtags on the last line

X (Twitter) post rules:
- HARD LIMIT: 280 characters total — COUNT EVERY CHARACTER
- Single punchy idea: hot take, relatable observation, or counterintuitive insight
- 0–2 hashtags only`

function buildPrompt(topic) {
  return `Today is ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}.

Generate one LinkedIn post and one X (Twitter) post for this software engineering topic:
- id: "${topic.id}" | "${topic.label}" — ${topic.description}

Return ONLY valid JSON in this exact shape:
{
  "linkedin": "<post text with \\n for paragraph breaks>",
  "twitter": "<tweet under 280 chars>"
}

Pick a specific, fresh angle — not a generic overview.`
}

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: corsHeaders() }
  }
  if (event.httpMethod !== 'POST') {
    return respond(405, { error: 'Method not allowed' })
  }
  if (!process.env.GEMINI_API_KEY) {
    return respond(500, { error: 'Server misconfiguration: API key missing.' })
  }

  let topic
  try {
    const body = JSON.parse(event.body || '{}')
    topic = body.topic
    if (!topic?.id || !topic?.label) {
      return respond(400, { error: '"topic" with id and label is required.' })
    }
  } catch {
    return respond(400, { error: 'Invalid JSON body.' })
  }

  try {
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY)
    const model = genAI.getGenerativeModel({
      model: 'gemini-2.0-flash',
      systemInstruction: SYSTEM_PROMPT,
      generationConfig: {
        responseMimeType: 'application/json',
        temperature: 0.85,
        maxOutputTokens: 1500,
      },
    })

    const result = await model.generateContent(buildPrompt(topic))
    const raw = result.response.text()

    let parsed
    try {
      parsed = JSON.parse(raw)
    } catch {
      return respond(502, { error: 'Failed to parse AI response. Please try again.' })
    }

    if (!parsed.linkedin || !parsed.twitter) {
      return respond(502, { error: 'Incomplete response from AI. Please try again.' })
    }

    // Merge this topic into today's Blobs entry
    try {
      const store = getStore('daily-posts')
      const todayIST = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' })
      const existing = await store.get(todayIST).then(r => r ? JSON.parse(r) : { posts: {} }).catch(() => ({ posts: {} }))
      existing.posts[topic.id] = parsed
      existing.generatedAt = new Date().toISOString()
      await store.set(todayIST, JSON.stringify(existing))
    } catch (blobErr) {
      console.warn('[generate-posts] Failed to save to Blobs:', blobErr.message)
    }

    return respond(200, { topicId: topic.id, post: parsed })
  } catch (err) {
    const isRateLimit = err?.status === 429
      || err?.message?.toLowerCase().includes('quota')
      || err?.message?.toLowerCase().includes('rate')
    if (isRateLimit) return respond(429, { error: 'Rate limit hit. Please wait a moment and try again.' })
    console.error('[generate-posts] Error:', err)
    return respond(500, { error: 'Failed to generate. Please try again.' })
  }
}

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  }
}

function respond(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', ...corsHeaders() },
    body: JSON.stringify(body),
  }
}
