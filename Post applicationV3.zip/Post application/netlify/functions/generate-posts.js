import { GoogleGenerativeAI } from '@google/generative-ai'
import { getStore } from '@netlify/blobs'

const SYSTEM_PROMPT = `You are a social media content strategist and ghostwriter specialising in software engineering content. You write for a senior software engineer's personal brand on LinkedIn and X (Twitter).

Your writing style:
- Authentic and conversational — sounds like a real engineer, not a content marketer
- Specific and concrete — includes realistic scenarios, numbers, and technical detail
- Avoids overused phrases: "game-changer", "paradigm shift", "In today's fast-paced world"
- Direct and opinionated — shares genuine takes, not generic advice

LinkedIn post rules:
- 150–280 words
- Strong hook in the first line (NOT "Today I want to talk about...")
- Short paragraphs with blank lines between them for readability
- Ends with a thought-provoking question or punchy insight
- 4–5 relevant hashtags on the last line

X (Twitter) post rules:
- HARD LIMIT: 280 characters total — COUNT EVERY CHARACTER
- Single punchy idea: hot take, relatable observation, or counterintuitive insight
- 0–2 hashtags only`

function buildPrompt(topics) {
  return `Today is ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}.

Generate one LinkedIn post and one X (Twitter) post for each of these ${topics.length} software engineering topics.

Topics:
${topics.map(t => `- id: "${t.id}" | "${t.label}" — ${t.description}`).join('\n')}

Return ONLY valid JSON in this exact shape:
{
  "posts": {
    "<topic-id>": {
      "linkedin": "<post text with \\n for paragraph breaks>",
      "twitter": "<tweet under 280 chars>"
    }
  }
}

Required topic IDs: ${topics.map(t => `"${t.id}"`).join(', ')}.
Pick a specific sub-angle for each — keep content fresh and varied.`
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

async function generateBatch(model, topics) {
  const result = await model.generateContent(buildPrompt(topics))
  const raw = result.response.text()
  const parsed = JSON.parse(raw)
  if (!parsed.posts || typeof parsed.posts !== 'object') {
    throw new Error('Unexpected response shape from Gemini')
  }
  return parsed.posts
}

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: corsHeaders() }
  }
  if (event.httpMethod !== 'POST') {
    return respond(405, { error: 'Method not allowed' })
  }
  if (!process.env.GEMINI_API_KEY) {
    console.error('[generate-posts] GEMINI_API_KEY is not set')
    return respond(500, { error: 'Server misconfiguration: API key missing.' })
  }

  let topics
  try {
    const body = JSON.parse(event.body || '{}')
    topics = body.topics
    if (!Array.isArray(topics) || topics.length === 0) {
      return respond(400, { error: '"topics" array is required.' })
    }
  } catch {
    return respond(400, { error: 'Invalid JSON body.' })
  }

  try {
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY)
    const model = genAI.getGenerativeModel({
      model: 'gemini-2.0-flash',
      systemInstruction: SYSTEM_PROMPT,
      generationConfig: {
        responseMimeType: 'application/json',
        temperature: 0.85,
        maxOutputTokens: 3000,
      },
    })

    // One topic per request — smallest possible payload, zero rate limit risk
    const allPosts = {}
    for (let i = 0; i < topics.length; i++) {
      const batchPosts = await generateBatch(model, [topics[i]])
      Object.assign(allPosts, batchPosts)
      if (i < topics.length - 1) await sleep(500)
    }

    // Fill any missing topics gracefully
    for (const { id } of topics) {
      if (!allPosts[id]) {
        allPosts[id] = {
          linkedin: 'Content for this topic could not be generated. Please regenerate.',
          twitter:  'Content for this topic could not be generated. Please regenerate.',
        }
      }
    }

    // Persist to Netlify Blobs so the scheduled job and get-posts stay in sync
    try {
      const store = getStore('daily-posts')
      const todayIST = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' })
      await store.set(todayIST, JSON.stringify({
        posts: allPosts,
        generatedAt: new Date().toISOString(),
        source: 'manual',
      }))
    } catch (blobErr) {
      console.warn('[generate-posts] Failed to save to Blobs:', blobErr.message)
    }

    return respond(200, { posts: allPosts })
  } catch (err) {
    const isRateLimit = err?.status === 429
      || err?.message?.toLowerCase().includes('quota')
      || err?.message?.toLowerCase().includes('rate')
      || err?.message?.toLowerCase().includes('429')
    if (isRateLimit) return respond(429, { error: 'rate_limited' })
    console.error('[generate-posts] Error:', err)
    return respond(500, { error: 'Failed to generate posts. Please try again.' })
  }
}

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  }
}

function respond(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', ...corsHeaders() },
    body: JSON.stringify(body),
  }
}
